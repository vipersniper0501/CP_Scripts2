!#/bin/bash 

UserName=root 
dist=distro 
ssh=y 
ftp=n 
proftp= 
vsftpd= 
web=n 
apaweb= 
nginweb= 
smb=n 
sql=n 
rsnc=n
